package com.sailpoint.plugin.testui.rest;

class IdentityInfoDTO
{
	private String firstName;
	private String lastName;
	private String name;
	private String displayName;
	
    public String getFirstName()
    {
    	return this.firstName;
    }
  
    public void setFirstName(String firstName)
    {
    	this.firstName = firstName;
    }

    public String getLastName()
    {
    	return this.lastName;
    }
  
    public void setLastName(String lastName)
    {
    	this.lastName = lastName;
    }
    
    public String getName() {
		return this.name;
	}

	public void setName(String var1) {
		this.name = var1;
	}

	public String getDisplayName() {
		return this.displayName;
	}

	public void setDisplayName(String var1) {
		this.displayName = var1;
	}
}