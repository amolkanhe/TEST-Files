package com.sailpoint.plugin.testui.rest;

import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONException;
import sailpoint.api.SailPointContext;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.QueryOptions;
import sailpoint.plugin.PluginContext;
import sailpoint.tools.GeneralException;


public class AllService {
	private PluginContext pluginContext;
	private SailPointContext context;
	private String date;

	public AllService(PluginContext var1, SailPointContext var2, String var3) {
		this.pluginContext = var1;
		this.context = var2;
		this.date = var3;
	}

	public AllService(SailPointContext var1) {
		this.context = var1;
	}

	/**public ArrayList<ManagerEntity> getManagersList() throws GeneralException, JSONException {
		Filter var1 = Filter.eq("managerStatus", true);
		QueryOptions var2 = new QueryOptions();
		var2.addFilter(var1);
		Iterator var3 = this.context.search(Identity.class, var2);
		ArrayList var4 = new ArrayList();
		if (null != var3) {
			while (var3.hasNext()) {
				Identity var5 = (Identity) var3.next();
				ManagerEntity var6 = new ManagerEntity();
				var6.setDisplayName(var5.getDisplayName());
				var6.setName(var5.getName());
				var4.add(var6);
			}
		}

		return var4;
	}		**/

	public ArrayList<String> getSubordinates(String var1) throws GeneralException {
		ArrayList var2 = new ArrayList();
		Filter var3;
		QueryOptions var4;
		Iterator var5;
		Identity var6;
		if (null != var1) {
			var3 = Filter.eq("platform", var1);
			var4 = new QueryOptions();
			var4.addFilter(var3);
			var5 = this.context.search(Identity.class, var4);
			if (null != var5) {
				while (var5.hasNext()) {
					var6 = (Identity) var5.next();
					var2.add(var6.getManager().getDisplayName() + "-" + var6.getName() + "-" + var6.getDisplayName());
					//var2.add(var6.getName() + "-" + var6.getDisplayName() +"-" +var6.getManager().getDisplayName());
				}
			}
		} 

		return var2;
	}
}
