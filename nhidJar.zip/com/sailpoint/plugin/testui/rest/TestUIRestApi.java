package com.sailpoint.plugin.testui.rest;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import sailpoint.api.SailPointContext;
import sailpoint.object.Identity;
import sailpoint.rest.plugin.AllowAll;
import sailpoint.rest.plugin.BasePluginResource;

@Path("testuirest")
@AllowAll
public class TestUIRestApi extends BasePluginResource
{
	@Override
	public String getPluginName() 
	{
		return "testui";
	}
	@POST
	@Path("getIdentityInfo")
	@Produces({"application/json"})
	@Consumes({"application/json"})
	@AllowAll
	
	
	/**
	public IdentityInfoDTO getIdentityInfo() throws Exception 
	{
		IdentityInfoDTO idInfo = new IdentityInfoDTO();
		
		HttpServletRequest request = this.getRequest();
		String identityName = request.getParameter("identity");
		SailPointContext context = getContext();
		Identity iden = context.getObjectByName(Identity.class, identityName);
		idInfo.setFirstName((String)iden.getAttribute("firstname"));
		idInfo.setLastName((String)iden.getAttribute("lastname"));
		return idInfo;
	} **/

	
	
	public ArrayList<String> getSubOrdinates(@QueryParam("platform") String var1) throws GeneralException {
		SailPointContext var2 = this.getContext();
		ArrayList var3 = this.getSubOrdinates(var2).getSubordinates(var1);
		Collections.sort(var3);
		return var3;
	}

	private AllService getSubOrdinates(SailPointContext var1) {
		return new AllService(var1);
	}
}