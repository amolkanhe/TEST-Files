package com.sailpoint.plugin.testui.rest;
import com.sailpoint.plugin.testui.rest.AllService;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import sailpoint.api.SailPointContext;
import sailpoint.object.Identity;
import sailpoint.rest.plugin.AllowAll;
import sailpoint.rest.plugin.BasePluginResource;

import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONException;
import sailpoint.object.Filter;
import sailpoint.object.QueryOptions;
import sailpoint.plugin.PluginContext;
import sailpoint.tools.GeneralException;
import java.util.Collections;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import sailpoint.rest.plugin.RequiredRight;




@Path("testuirest")
@AllowAll
public class TestUIRestApi extends BasePluginResource{
	
	@Override
	public String getPluginName() 
	{
		return "testui";
	}
	
	
	@POST
	@Path("getIdentityInfo")
	@Produces({"application/json"})
	@Consumes({"application/json"})
	@AllowAll
	
	
	public ArrayList<String> getUsers(@QueryParam("workerType") String workerType) throws GeneralException {
		SailPointContext context = getContext();
		ArrayList<String> valueString = getUsers(context).getUsers(workerType);
		Collections.sort(valueString);
		return valueString;
	}

	private AllService getUsers(SailPointContext context) {
		return new AllService(context);
	}
	
} 