package com.sailpoint.plugin.testui.rest;

import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONException;
import sailpoint.api.SailPointContext;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.QueryOptions;
import sailpoint.plugin.PluginContext;
import sailpoint.tools.GeneralException;




public class AllService {
	private PluginContext pluginContext;
	private SailPointContext context;
	private String date;

	// ========= constructor ==================
	public AllService(PluginContext paramPluginContext, SailPointContext context, String date) {
		this.pluginContext = paramPluginContext;
		this.context = context;
		this.date = date;
	}

	public AllService(SailPointContext context) {
		this.context = context;
	}

	// ============= Get User list ===============
public ArrayList<String> getUsers(String workerType) throws GeneralException {
		ArrayList<String> userList = new ArrayList<String>();
		

if (null != workerType) {

			Filter myFilter = Filter.eq("workerType", workerType);
			QueryOptions qo = new QueryOptions();
			qo.addFilter(myFilter);

			Iterator<Identity> iter = context.search(Identity.class, qo);

			if (null != iter) {
				while (iter.hasNext()) {
					Identity identity = (Identity) iter.next();
					userList.add(identity.getDisplayName()+"-"+identity.getManager().getDisplayName()+ "-"+ identity.getAttribute("workerType"));

				}
			}
		} 
	return userList;	
		
	}
}
