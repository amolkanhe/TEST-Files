package com.sailpoint.plugin.testui.rest;

class IdentityInfoDTO
{
	private String firstName;
	private String lastName;
	private String name;
	private String displayName;
	
    public String getFirstName()
    {
    	return this.firstName;
    }
  
    public void setFirstName(String firstName)
    {
    	this.firstName = firstName;
    }

    public String getLastName()
    {
    	return this.lastName;
    }
  
    public void setLastName(String lastName)
    {
    	this.lastName = lastName;
    }
    
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	
}