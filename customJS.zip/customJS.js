//<script src="ui/js/jquery.min.js"></script>
var cutomBaseURL = 'http://localhost:8080';
function getURLParameter(sParam)
{
	var sPageURL = window.location.search.substring(1);
	var sURLVariables = sPageURL.split('&');
	var sParameterName;
	for (var i = 0; i < sURLVariables.length; i++)
	{
		sParameterName = sURLVariables[i].split('=');
		if (sParameterName[0] == sParam)
			return sParameterName[1];
	}
	return '';
}

if(getURLParameter('page')!='')
	jQuery('#pageContainer').load('/identityiq/plugin/testui/ui/pages/'+getURLParameter('page')+'.html');

function fn_navigate_To_OtherPage(newPage,callback_fn,callback_fn_args)
{
	if(!(callback_fn_args==null || callback_fn==null))
		jQuery('#pageContainer').load('/identityiq/plugin/testui/ui/pages/'+newPage+'.html',function(data){window[callback_fn](callback_fn_args);});
	else if(callback_fn_args==null && callback_fn!=null)
		jQuery('#pageContainer').load('/identityiq/plugin/testui/ui/pages/'+newPage+'.html',function(data){window[callback_fn]();});
	else if(callback_fn_args==null && callback_fn==null)
		jQuery('#pageContainer').load('/identityiq/plugin/testui/ui/pages/'+newPage+'.html');
}

//////////////////////////////////////////Page Specific Scripts////////////////////////////////////////

function fn_loadPage1()
{
	fn_navigate_To_OtherPage('page1',null,null);
}

function fn_loadPage2()
{
	var platform = document.getElementById('platform').value;
	fn_navigate_To_OtherPage('page2','fn_searchIdentity',platform);
}

/*
function fn_searchIdentity(idenName)
{
	xhttp = new XMLHttpRequest();
	xhttp.open("POST", "/identityiq/plugin/rest/testuirest/getIdentityInfo?identity="+idenName, true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.send();
	
	xhttp.onreadystatechange = function()
	{
		if(this.readyState == 4)
		{
			if (this.status == 200)
			{
				var txt=this.responseText;
				var jsonData = JSON.parse(txt);
				document.getElementById('fnval').value=jsonData.firstName;
				document.getElementById('lnval').value=jsonData.lastName;
			}
		}
	}
}
*/
////////////////////////////////// Page 3 details //////////////////////////////////////////

		function fn_searchIdentity()
	 
		 {
			 var restUrl = cutomBaseURL + PluginHelper.getPluginRestUrl('testuirest/getIdentityInfo');
			 var platform = document.getElementById("platform").value;
			    $.ajax({  
			        type: "GET",  
			        url: restUrl,
			        beforeSend: function(xhr){xhr.setRequestHeader('X-XSRF-TOKEN', PluginHelper.getCsrfToken());},
			        data: 
			        { 
			        	platform: platform 
			        },
			        success: function (data) 
			        {  
			        	//==== deleting all the rows including header of existing table === 
			        	$("#subOrdinateTable").find("tr").remove();
			        	
			        	//==== rows and cell creation of the table ===
			            subOrdinateTable(data);
			        }  
			    }); 
	 }

//============= create sub-ordinate table ===
function subOrdinateTable(data)
{
	
	var tableValue = data;
	var tableValueLength = tableValue.length;
	var table = document.getElementById("subOrdinateTable");
	
	//==== hard coded header of table====
	var headerRow = table.insertRow(0);
	var headerCell1 = headerRow.insertCell(0);
	var headerCell2 = headerRow.insertCell(1);
	var headerCell3 = headerRow.insertCell(2);
	
	headerCell1.innerHTML = "<b>Display Name</b>";
	headerCell2.innerHTML = "<b>Manager</b>";
	headerCell3.innerHTML = "<b>Platform</b>";
	
    for (var i = 0; i < tableValueLength; i++) 
    {
    	var row = table.insertRow(i+1);
    	var rowValues = tableValue[i].split("-");
    	var rowValuesLength = rowValues.length;
    	
		//===== create Cells ====
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		//var cell4 = row.insertCell(3);
		
		//==== insert values in cells ===
		cell1.innerHTML = rowValues[0];
		cell2.innerHTML = rowValues[1];
		cell3.innerHTML = rowValues[2];
		//cell4.innerHTML = rowValues[3];
    }
}
