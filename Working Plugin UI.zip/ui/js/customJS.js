//<script src="ui/js/jquery.min.js"></script>
function getURLParameter(sParam)
{
	var sPageURL = window.location.search.substring(1);
	var sURLVariables = sPageURL.split('&');
	var sParameterName;
	for (var i = 0; i < sURLVariables.length; i++)
	{
		sParameterName = sURLVariables[i].split('=');
		if (sParameterName[0] == sParam)
			return sParameterName[1];
	}
	return '';
}

if(getURLParameter('page')!='')
	jQuery('#pageContainer').load('/identityiq/plugin/testui/ui/pages/'+getURLParameter('page')+'.html');

function fn_navigate_To_OtherPage(newPage,callback_fn,callback_fn_args)
{
	if(!(callback_fn_args==null || callback_fn==null))
		jQuery('#pageContainer').load('/identityiq/plugin/testui/ui/pages/'+newPage+'.html',function(data){window[callback_fn](callback_fn_args);});
	else if(callback_fn_args==null && callback_fn!=null)
		jQuery('#pageContainer').load('/identityiq/plugin/testui/ui/pages/'+newPage+'.html',function(data){window[callback_fn]();});
	else if(callback_fn_args==null && callback_fn==null)
		jQuery('#pageContainer').load('/identityiq/plugin/testui/ui/pages/'+newPage+'.html');
}

//////////////////////////////////////////Page Specific Scripts////////////////////////////////////////

function fn_loadPage1()
{
	fn_navigate_To_OtherPage('page1',null,null);
}

function fn_loadPage2()
{
	var idenName = document.getElementById('iden').value;
	fn_navigate_To_OtherPage('page2','fn_searchIdentity',idenName);
}

function fn_searchIdentity(idenName)
{
	xhttp = new XMLHttpRequest();
	xhttp.open("POST", "/identityiq/plugin/rest/testuirest/getIdentityInfo?identity="+idenName, true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.send();
	
	xhttp.onreadystatechange = function()
	{
		if(this.readyState == 4)
		{
			if (this.status == 200)
			{
				var txt=this.responseText;
				var jsonData = JSON.parse(txt);
				document.getElementById('fnval').value=jsonData.firstName;
				document.getElementById('lnval').value=jsonData.lastName;
			}
		}
	}
}
